﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using SQLite;

namespace VirtualEmpTestApplication.DataManager
{
    public class BDManagerConnection
    {
        public static string dbName = "LnTMobilityContainer.db3";
        public static SQLite.SQLiteConnection _connection;
        public static SQLite.SQLiteConnection connection
        {
            get
            {
                if (_connection == null)
                {
                    _connection = GetConnection();
                }
                return _connection;
            }
        }
        public static SQLiteConnection GetConnection()
        {
            var path = Path.Combine(System.Environment.
              GetFolderPath(System.Environment.SpecialFolder.Personal), dbName);
            return new SQLiteConnection(path);
        }
    }
}