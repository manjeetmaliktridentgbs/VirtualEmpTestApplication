﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using VirtualEmpTestApplication.Models;

namespace VirtualEmpTestApplication.DataManager
{
    public class PackageDimensDAL
    {
        public PackageDimensDAL()
        {
            BDManagerConnection.connection.CreateTable<PackageDimensModel>();
        }

        //Get all PackageDimenss  
        public List<PackageDimensModel> GetAll()
        {
            List<PackageDimensModel> PackageDimensModels = new List<PackageDimensModel>();
            PackageDimensModels = BDManagerConnection.connection.Table<PackageDimensModel>().ToList();
            return PackageDimensModels;
        }

        //Get specific PackageDimens  
        public PackageDimensModel GetItemByID(int id)
        {
            return BDManagerConnection.connection.Table<PackageDimensModel>().Where(i => i.PackageDimensID == id).FirstOrDefault();
        }

        //Delete specific PackageDimens  
        public void Update(PackageDimensModel PackageDimens)
        {
            BDManagerConnection.connection.Update(PackageDimens);
        }
        //Add new PackageDimens to DB  
        public void UpdateAll(List<PackageDimensModel> lstPackageDimensModel)
        {
            BDManagerConnection.connection.UpdateAll(lstPackageDimensModel);
        }

        //Delete specific PackageDimens  
        public void Delete(int id)
        {
            BDManagerConnection.connection.Delete<PackageDimensModel>(id);
        }

        //Add new PackageDimens to DB  
        public void Insert(PackageDimensModel PackageDimens)
        {
            BDManagerConnection.connection.Insert(PackageDimens);
        }

        //Add new PackageDimens to DB  
        public void InsertAll(ObservableCollection<PackageDimensModel> lstPackageDimensModel)
        {
            BDManagerConnection.connection.InsertAll(lstPackageDimensModel);
        }

        //Delete specific PackageDimens  
        public void DeleteAll()
        {
            BDManagerConnection.connection.DeleteAll<PackageDimensModel>();
        }
    }
}