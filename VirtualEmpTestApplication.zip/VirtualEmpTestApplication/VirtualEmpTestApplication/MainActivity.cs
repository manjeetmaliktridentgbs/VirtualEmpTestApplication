﻿using Android.Widget;
using Android.OS;
using System;
using FragmentManager = Android.Support.V4.App.FragmentManager;
using Android.App;
using VirtualEmpTestApplication.Fragments;

namespace VirtualEmpTestApplication
{
    [Activity(Label = "@string/app_name", Theme = "@style/AppTheme", MainLauncher = true)]
    public class MainActivity : Activity
    {
        public static int Screen_Width { get; set; }
        public static int Screen_Height { get; set; }
        
        protected override void OnCreate(Bundle savedInstanceState)
        {
            Screen_Width = (int)(Resources.DisplayMetrics.WidthPixels / Resources.DisplayMetrics.Density);
            Screen_Height = (int)(Resources.DisplayMetrics.HeightPixels / Resources.DisplayMetrics.Density);
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.activity_main);
            ShowFragment();
        }
        protected void ShowFragment()
        {
            var trans = FragmentManager.BeginTransaction();
            trans.Add(Resource.Id.fragmentContainer, new MainMenuFragment(), "MainMenuFragment");
            trans.Commit();
        }
    }
}

