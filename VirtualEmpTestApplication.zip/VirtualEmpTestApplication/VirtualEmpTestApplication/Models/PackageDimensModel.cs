﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace VirtualEmpTestApplication.Models
{
    public class PackageDimensModel
    {
        public int ID { get; set; }
        public int PackageDimensID { get; set; }
        public string PackageBarCode { get; set; }
        public decimal PackageHeight { get; set; }
        public decimal PackageWidth { get; set; }
        public decimal PackageDepth { get; set; }
        public string PackageIcon { get; set; }
    }
}