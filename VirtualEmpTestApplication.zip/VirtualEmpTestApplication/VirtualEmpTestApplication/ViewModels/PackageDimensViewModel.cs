﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using VirtualEmpTestApplication.DataManager;
using VirtualEmpTestApplication.Models;

namespace VirtualEmpTestApplication.ViewModels
{
    public class PackageDimensViewModel
    {  
        public List<PackageDimensModel> FillPackageData()
        {
            List<PackageDimensModel> lstPackageDimensModel = new List<PackageDimensModel>();
            PackageDimensDAL objPackageDimensDAL = new PackageDimensDAL();
            lstPackageDimensModel = objPackageDimensDAL.GetAll();
            return lstPackageDimensModel;
        }
    }
}