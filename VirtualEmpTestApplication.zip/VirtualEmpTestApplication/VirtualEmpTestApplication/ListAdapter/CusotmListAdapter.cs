﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using VirtualEmpTestApplication.Models;

namespace VirtualEmpTestApplication.ListAdapter
{
    public class CusotmListAdapter : BaseAdapter<PackageDimensModel>
    {
        Activity context;
        List<PackageDimensModel> list;
        private Context context1;
        private List<PackageDimensModel> lstPackageDimensModel;

        public CusotmListAdapter(Activity _context, List<PackageDimensModel> _list)
            : base()
        {
            this.context = _context;
            this.list = _list;
        }

        public CusotmListAdapter(Context context1, List<PackageDimensModel> lstPackageDimensModel)
        {
            this.context1 = context1;
            this.lstPackageDimensModel = lstPackageDimensModel;
        }

        public override int Count
        {
            get { return list.Count; }
        }

        public override long GetItemId(int position)
        {
            return position;
        }

        public override PackageDimensModel this[int index]
        {
            get { return list[index]; }
        }

        public override View GetView(int position, View convertView, ViewGroup parent)
        {
            View view = convertView;

            // re-use an existing view, if one is available
            // otherwise create a new one
            if (view == null)
                view = context.LayoutInflater.Inflate(Resource.Layout.ListItemRow, parent, false);

            PackageDimensModel item = this[position];
            view.FindViewById<TextView>(Resource.Id.Title).Text = item.PackageBarCode;
            view.FindViewById<TextView>(Resource.Id.Description).Text ="Height:" + item.PackageHeight +","+
                "Width:" + item.PackageWidth;

            //using (var imageView = view.FindViewById<ImageView>(Resource.Id.Thumbnail))
            //{
            //    string url = Android.Text.Html.FromHtml(item.PackageIcon).ToString();

            //    //Download and display image
            //    Koush.UrlImageViewHelper.SetUrlDrawable(imageView,
            //        url, Resource.Drawable.Placeholder);
            //}
            return view;
        }
    }
}