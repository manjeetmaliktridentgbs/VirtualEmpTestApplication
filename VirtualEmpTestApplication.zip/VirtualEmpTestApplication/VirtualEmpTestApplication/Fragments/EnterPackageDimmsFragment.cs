﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using VirtualEmpTestApplication.DataManager;
using VirtualEmpTestApplication.Models;

namespace VirtualEmpTestApplication.Fragments
{
    public class EnterPackageDimmsFragment: Fragment
    {
        PackageDimensModel objPackageDimensModel = new PackageDimensModel();
        EditText txtenterBarcode = null;
        EditText txtenterwidth = null;
        EditText txtEnterheight = null;
        EditText txtPackageDepth = null;
        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            View objView = inflater.Inflate(Resource.Layout.EnterPackageDimmsFragmentView, container, false);
            if (objPackageDimensModel == null)
                objPackageDimensModel = new PackageDimensModel();
            txtenterBarcode = (EditText)objView.FindViewById(Resource.Id.enterBarcode);            
            txtenterwidth = (EditText)objView.FindViewById(Resource.Id.enterwidthID);           
            txtEnterheight = (EditText)objView.FindViewById(Resource.Id.EnterheightID);            
            txtPackageDepth = (EditText)objView.FindViewById(Resource.Id.EnterPackageDepth);
            //ImageView objImageView = (ImageView)objView.FindViewById(Resource.Id.EnteryimageViewID);
            //objImageView.SetImageResource(Resource.Mipmap.VirtuslEmployee);
            Button btnSaveID = (Button)objView.FindViewById(Resource.Id.btnSaveID);
            if (btnSaveID != null)
                btnSaveID.Click += btnEnterPackageDimms_Clicked;
            Button btnResetID = (Button)objView.FindViewById(Resource.Id.btnReseID);
            if (btnResetID != null)
                btnResetID.Click += btnResetPackageDimms_Clicked;
            return objView;
        }

        private void btnEnterPackageDimms_Clicked(object sender, EventArgs e)
        {
            objPackageDimensModel.PackageBarCode = txtenterBarcode.Text;
            if (!string.IsNullOrEmpty(txtenterwidth.Text))
                objPackageDimensModel.PackageWidth = Convert.ToDecimal(txtenterwidth.Text);
            if (!string.IsNullOrEmpty(txtEnterheight.Text))
                objPackageDimensModel.PackageHeight = Convert.ToDecimal(txtEnterheight.Text);
            if (!string.IsNullOrEmpty(txtPackageDepth.Text))
                objPackageDimensModel.PackageDepth = Convert.ToDecimal(txtPackageDepth.Text);
            if (IsValid())
            {
                PackageDimensDAL objPackageDimensDAL = new PackageDimensDAL();
                bool isNotValidDecimalEntry = false;

                if (!(objPackageDimensModel.PackageWidth * (decimal)Math.Pow(10, 2) % 1 == 0))
                {
                    isNotValidDecimalEntry = true;
                    Toast.MakeText(this.Activity, "Decimal value can't have more than 2 decimal places", ToastLength.Long).Show();
                }
                if (!(objPackageDimensModel.PackageHeight * (decimal)Math.Pow(10, 2) % 1 == 0))
                {
                    isNotValidDecimalEntry = true;
                    Toast.MakeText(this.Activity, "Decimal value can't have more than 2 decimal places", ToastLength.Long).Show();
                }
                if (!(objPackageDimensModel.PackageDepth * (decimal)Math.Pow(10, 2) % 1 == 0))
                {
                    isNotValidDecimalEntry = true;
                    Toast.MakeText(this.Activity, "Decimal value can't have more than 2 decimal places", ToastLength.Long).Show();
                }
                if(!isNotValidDecimalEntry)
                {
                    objPackageDimensDAL.Insert(objPackageDimensModel);
                    Toast.MakeText(this.Activity, "Package inserted successfully!", ToastLength.Long).Show();
                }
            }
        }
        private void btnResetPackageDimms_Clicked(object sender, EventArgs e)
        {
            txtenterBarcode.Text = string.Empty;
            txtenterwidth.Text = string.Empty;
            txtEnterheight.Text = string.Empty;
            txtPackageDepth.Text = string.Empty;
        }
        public bool IsValid()
        {
            bool isValid = false;
            if (string.IsNullOrWhiteSpace(objPackageDimensModel.PackageBarCode))
            {
                Toast.MakeText(this.Activity, "Enter valid package bar code!", ToastLength.Long).Show();
                return false;
            }

            else if (objPackageDimensModel.PackageWidth < 1)
            {
                Toast.MakeText(this.Activity, "Enter valid packagew width!", ToastLength.Long).Show();
                return false;
            }

            else if (objPackageDimensModel.PackageHeight < 1)
            {
                Toast.MakeText(this.Activity, "Enter valid package height!", ToastLength.Long).Show();
                return false;
            }

            else if (objPackageDimensModel.PackageDepth < 1)
            {
                Toast.MakeText(this.Activity, "Enter valid package depth!", ToastLength.Long).Show();
                return false;
            }
            
            else
                isValid = true;
            return isValid;
        }

        public bool CheckDecimalValue(decimal inputDecimalValue)
        {
            bool isValidValue = false;
            Regex regex = new Regex(@"\d+(\.\d{1,2})");
            Match match = regex.Match(Convert.ToString(inputDecimalValue));
            if (match.Success)
                isValidValue = true;
            return isValidValue;
        }
    }
}