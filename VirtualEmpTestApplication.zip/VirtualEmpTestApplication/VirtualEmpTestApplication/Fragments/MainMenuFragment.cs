﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace VirtualEmpTestApplication.Fragments
{
    public class MainMenuFragment: Fragment
    {
       
        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            View objView = inflater.Inflate(Resource.Layout.MainMenuFragmentView,container,false);
            //ImageView objImageView = (ImageView)objView.FindViewById(Resource.Id.MainMenuimageViewID);
            //objImageView.SetImageResource(Resource.Mipmap.VirtuslEmployee);
            Button objShowPackage = (Button)objView.FindViewById(Resource.Id.OpenPackageDimms);
            if (objShowPackage != null)
                objShowPackage.Click += btnobjShowPackage_Clicked;
            Button objEnterPackageDimms = (Button)objView.FindViewById(Resource.Id.EnterPackageDimms);
            objEnterPackageDimms.Click += btnEnterPackageDimms_Clicked;
            return objView;
        }
        private void btnEnterPackageDimms_Clicked(object sender, EventArgs e)
        {
            var trans = FragmentManager.BeginTransaction();
            trans.Add(Resource.Id.fragmentContainer, new EnterPackageDimmsFragment(), "EnterPackageDimmsFragment");
            trans.AddToBackStack(null);
            trans.Commit();
        }
        private void btnobjShowPackage_Clicked(object sender, EventArgs e)
        {
            var showTrans = FragmentManager.BeginTransaction();
            showTrans.Add(Resource.Id.fragmentContainer, new ShowPackageDimmsFragment(), "ShowPackageDimmsFragment");
            showTrans.AddToBackStack(null);
            showTrans.Commit();
        }

    }
}