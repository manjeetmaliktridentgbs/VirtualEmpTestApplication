﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using VirtualEmpTestApplication.ListAdapter;
using VirtualEmpTestApplication.Models;
using VirtualEmpTestApplication.ViewModels;

namespace VirtualEmpTestApplication.Fragments
{
    public class ShowPackageDimmsFragment:Fragment
    {
        List<PackageDimensModel> lstPackageDimensModel = new List<PackageDimensModel>();
        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            View objView = inflater.Inflate(Resource.Layout.ShowPackageDimmsFragmentView, container, false);
            //Initializing listview
            ImageView objImageView = (ImageView)objView.FindViewById(Resource.Id.ShowPackageimageViewID);
            objImageView.SetImageResource(Resource.Mipmap.VirtuslEmployee);
            PackageDimensViewModel objPackageDimensViewModel = new PackageDimensViewModel();
            lstPackageDimensModel = objPackageDimensViewModel.FillPackageData();
            if(lstPackageDimensModel != null && lstPackageDimensModel.Count > 0)
            {
                ListView listView = (ListView)objView.FindViewById(Resource.Id.ListView);
                listView.ItemClick += OnListItemClick;
                listView.Adapter = new CusotmListAdapter(this.Activity, lstPackageDimensModel);
            }
            return objView;

        }
        void OnListItemClick(object sender, AdapterView.ItemClickEventArgs e)
        {
            PackageDimensModel objPackageDimensModel = lstPackageDimensModel.ElementAt(e.Position);
            // Do whatever you like here
        }
    }
}